// Generates the static logo files from src/config/logoMark.mjs
//   node scripts/generate-brand.mjs        (or: npm run generate:brand)
//
// Outputs
//   public/logo/mark-light.svg, mark-dark.svg                  mark only
//   public/logo/logo-horizontal-light.svg / -dark.svg          mark + wordmark
//   public/logo/profile.svg, profile-1024.png                  social profile picture
//   src/app/icon.svg, src/app/apple-icon.png                   favicon + iOS icon
//
// NOTE: the wordmark in the *.svg files is live text set in Cormorant Garamond
// (falls back to Georgia). On the website the wordmark is rendered by the
// <Logo/> component with the loaded web font. For print / merch, open the SVG
// in a design tool with the font installed and convert text to outlines.

import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { markInner, BRAND, MARK_VIEWBOX } from "../src/config/logoMark.mjs";

const require = createRequire(import.meta.url);
function loadSharp() {
  for (const id of ["sharp", process.env.SHARP_PATH].filter(Boolean)) {
    try { return require(id); } catch { /* try next */ }
  }
  throw new Error("sharp not found. Run `npm install` first.");
}
const sharp = loadSharp();

const root = path.resolve(import.meta.dirname, "..");
const logoDir = path.join(root, "public", "logo");
fs.mkdirSync(logoDir, { recursive: true });
fs.mkdirSync(path.join(root, "src", "app"), { recursive: true });

const FONT = "'Cormorant Garamond', Georgia, 'Times New Roman', serif";
const write = (file, data) => fs.writeFileSync(file, data);

// tone "light" = for LIGHT backgrounds, "dark" = for DARK backgrounds
const tones = {
  light: { stroke: BRAND.green, accent: BRAND.gold, text: BRAND.ink },
  dark: { stroke: BRAND.goldLight, accent: BRAND.goldLight, text: BRAND.ivory },
};

for (const [tone, c] of Object.entries(tones)) {
  write(
    path.join(logoDir, `mark-${tone}.svg`),
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${MARK_VIEWBOX}" width="400" height="400" role="img" aria-label="Naksha Mehndi">${markInner(c.stroke, c.accent)}</svg>\n`,
  );
  write(
    path.join(logoDir, `logo-horizontal-${tone}.svg`),
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 380 100" width="760" height="200" role="img" aria-label="Naksha Mehndi">
  <g>${markInner(c.stroke, c.accent)}</g>
  <text x="122" y="60" font-family="${FONT}" font-size="50" font-weight="500" fill="${c.text}">Naksha</text>
  <text x="124" y="84" font-family="${FONT}" font-size="15" font-weight="500" letter-spacing="8" fill="${c.accent}">MEHNDI</text>
</svg>\n`,
  );
}

// Favicon: gold mark on Mehendi-green tile
const iconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="512" height="512">
  <rect width="100" height="100" rx="20" fill="${BRAND.green}"/>
  <g transform="translate(12 10) scale(0.76)">${markInner(BRAND.goldLight, BRAND.goldLight)}</g>
</svg>\n`;
write(path.join(root, "src", "app", "icon.svg"), iconSvg);
await sharp(Buffer.from(iconSvg)).resize(180, 180).png().toFile(path.join(root, "src", "app", "apple-icon.png"));

// Social profile picture (Instagram / WhatsApp Business / Facebook crop to a circle)
const profileSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="1024" height="1024">
  <rect width="400" height="400" fill="${BRAND.green}"/>
  <circle cx="200" cy="200" r="186" fill="none" stroke="${BRAND.goldLight}" stroke-width="1.2" opacity="0.6"/>
  <g transform="translate(110 62) scale(1.8)">${markInner(BRAND.goldLight, BRAND.goldLight)}</g>
  <text x="200" y="298" text-anchor="middle" font-family="${FONT}" font-size="38" font-weight="500" fill="${BRAND.ivory}">Naksha</text>
  <text x="199" y="322" text-anchor="middle" font-family="${FONT}" font-size="12" letter-spacing="7" fill="${BRAND.goldLight}">MEHNDI</text>
</svg>\n`;
write(path.join(logoDir, "profile.svg"), profileSvg);
await sharp(Buffer.from(profileSvg)).png().toFile(path.join(logoDir, "profile-1024.png"));

// Link-preview image (WhatsApp / Facebook / Google): logo + tagline on wine, with a real
// photo in an arch. Uses public/images/hero.jpg, so re-run after swapping that photo:
//   npm run generate:brand
const heroPath = path.join(root, "public", "images", "hero.jpg");
if (fs.existsSync(heroPath)) {
  const AW = 400, AH = 530;
  const archMask = Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${AW}" height="${AH}"><path d="M0 ${AH}V${AW / 2}A${AW / 2} ${AW / 2} 0 0 1 ${AW} ${AW / 2}V${AH}Z" fill="#fff"/></svg>`,
  );
  const arch = await sharp(heroPath)
    .resize(AW, AH, { fit: "cover", position: "attention" })
    .composite([{ input: archMask, blend: "dest-in" }])
    .png()
    .toBuffer();
  const ogSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
  <rect width="1200" height="630" fill="${BRAND.green}"/>
  <path d="M770 596V${50 + AW / 2}A${AW / 2 + 12} ${AW / 2 + 12} 0 0 1 ${770 + AW + 24} ${50 + AW / 2}V596" fill="none" stroke="${BRAND.goldLight}" stroke-width="1.5" transform="translate(-12 -4)"/>
  <g transform="translate(90 150) scale(2.6)">${markInner(BRAND.goldLight, BRAND.goldLight)}</g>
  <text x="90" y="470" font-family="${FONT}" font-size="104" font-weight="500" fill="${BRAND.ivory}">Naksha</text>
  <text x="96" y="520" font-family="${FONT}" font-size="26" letter-spacing="14" fill="${BRAND.goldLight}">MEHNDI</text>
  <text x="96" y="572" font-family="${FONT}" font-style="italic" font-size="30" fill="${BRAND.ivory}" opacity="0.85">Bridal &amp; Wedding Mehendi Artist</text>
</svg>`;
  await sharp(Buffer.from(ogSvg))
    .composite([{ input: arch, left: 770, top: 50 }])
    .jpeg({ quality: 88 })
    .toFile(path.join(root, "public", "images", "og-image.jpg"));
}

console.log("Brand assets written to public/logo, src/app and public/images/og-image.jpg");
