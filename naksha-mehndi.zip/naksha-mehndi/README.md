# Naksha Mehndi — Website

Single-page, scroll-driven website for **Naksha Mehndi**, a bridal & wedding Mehendi artist.
Built with Next.js (App Router), Tailwind CSS 3 and Framer Motion. No backend, no database, no required environment variables. WhatsApp enquiries are handled with a pre-filled `wa.me` link.

> **Status:** the client's real photos, phone/WhatsApp number and Instagram are in. Pricing, location, testimonials and policies are still **demo / placeholder** content, clearly tagged on the page and in the code. Search engines are **blocked** until you flip the launch flag (see [Launch checklist](#launch-checklist)).

---

## Commands

```bash
npm install          # first time only
npm run dev          # development server → http://localhost:3000
npm run build        # production build
npm run start        # serve the production build locally
```

Requires Node.js 18.18 or newer.

Optional helper script:

```bash
npm run generate:brand    # re-creates public/logo/*, the favicon and public/images/og-image.jpg
                          # (the link-preview image uses public/images/hero.jpg — re-run after swapping it)
```
It needs the `sharp` package, which `npm install` provides.

---

## Where to edit things — one file

**`src/config/siteConfig.js`** holds everything that changes per client:

| Section in the file | What it controls |
|---|---|
| `CONFIRMED` | Business name, phone, WhatsApp, email, hours, years of experience |
| `HERO_STATS` | Labels in the hero stats row (the services count is automatic) |
| `SERVICES` | The 10 services (names confirmed; descriptions are draft copy) |
| `COPY` | Tagline, description, SEO title and meta description |
| `INSTAGRAM`, `OTHER_SOCIALS` | Social links |
| `LOCATION` | Display name, Google Maps URL, address (for schema) |
| `PRICING` | The pricing list |
| `TESTIMONIALS` | Photo, name, event type, quote |
| `IMAGES`, `GALLERY`, `INSTAGRAM_IMAGES` | Which image file is used where |
| `PORTFOLIO_CATEGORIES` | Filter tabs (empty categories hide automatically) |
| `ENQUIRY` | Event types offered in the form |
| `LAUNCH_CHECKLIST` | Flags that remove demo tags, enable indexing and enable schema |

Search the file for **`DEMO — REPLACE BEFORE PRODUCTION`** to find every placeholder.

**Assumptions to check:** (1) the single number **+91 87547 91309** is used for both calls and WhatsApp — if WhatsApp is on a different number, change only `whatsappDigits`; (2) the country code `91` (India) is added in front of the number for `wa.me` links.

---

## Confirmed vs demo

| Confirmed (real) | Demo / placeholder |
|---|---|
| Name: Naksha Mehndi | Tagline & description (designer drafts) |
| Phone / WhatsApp: +91 87547 91309 | Pricing (`₹X,XXX` etc.) |
| Email: aknishtech27@gmail.com | Location + map URL |
| Hours: 9:00 AM – 7:00 PM | Testimonials (name, photo, text) |
| Experience: 10 years | Policies ("to be added") |
| The 10 services | Photo categories (designer's best guess) |
| Instagram: @nakshu_mehandhi | Logo & palette (designed for you, open to changes) |
| Work photos (10 supplied) | |

---

## Photos

The client's real photos are in `public/images/` (resized for the web, with hidden metadata such as GPS stripped). To swap one, replace the file **with the same name**. If the shape changes, update `width` / `height` in `siteConfig.js`.

| File | Used for |
|---|---|
| `hero.jpg` | Hero arch image |
| `bridal-1.jpg` | Small image on the hero |
| `about.jpg`, `about-2.jpg` | About section |
| `bridal-2.jpg` | Services arch image |
| `gallery-1.jpg` … `gallery-10.jpg` | Portfolio (set the `category` of each in `GALLERY`) |
| `instagram-1.jpg` … `instagram-6.jpg` | Square images in the Instagram strip |
| `og-image.jpg` | Link preview on WhatsApp / social (made by `npm run generate:brand`) |

Portfolio categories are the designer's best guess (Bridal, Traditional, Custom, Arabic, Baby Shower). A filter tab only appears if at least one photo uses it, so adding Engagement, Minimal or Party photos later just means setting that `category`.

**Logo files** (`public/logo/`): `mark-light.svg`, `mark-dark.svg`, `logo-horizontal-light.svg`, `logo-horizontal-dark.svg`, `profile.svg`, `profile-1024.png` (square, for Instagram / WhatsApp Business profile). Favicon: `src/app/icon.svg` and `src/app/apple-icon.png`.

---

## Brand

- **Concept:** a jharokha/mehrab arch holding a symmetrical lotus — fine line-work, like henna drawn by hand.
- **Colours ("Henna Rani"):** deep wine `#5E1533` · marigold `#F4B83F` · saffron `#B84E0A` · warm ivory `#FFF8EE` · peach blush `#FCE8DB` · dark plum-brown `#2E1119`. Defined in `tailwind.config.cjs` (token names are unchanged from v1: `mehndi` = wine, `gold` = saffron, `gold-light` = marigold) and in `src/config/logoMark.mjs` for the logo.
- **Fonts:** Cormorant Garamond (headings) + DM Sans (body), loaded from Google Fonts in `src/app/layout.js`.
- **Tagline (draft):** *Stories told in henna.* Alternatives: *Every line, a love letter.* / *Drawn by hand. Kept in memory.*

---

## Contact & booking flow

1. **WhatsApp (primary):** buttons in the navbar, hero, services, pricing, contact section, footer, and a slim sticky bar on mobile after the hero.
2. **Call (secondary):** `tel:` link in the contact section and footer.
3. **Email (third):** `mailto:` link.
4. **Enquiry form:** Name, Phone, Event Type, Event Date, Location, Number of People (optional), Preferred Service, Message → **Send Enquiry** opens `wa.me/<number>` with the message pre-filled. Name, phone and event type are required. Nothing is sent to or stored on a server.

The message format is built in `src/lib/contact.js` (`buildEnquiryMessage`).

---

## Launch checklist

In `src/config/siteConfig.js` → `LAUNCH_CHECKLIST`, set each flag to `true` **after** replacing the matching demo content. Demo tags disappear automatically.

- [ ] `copyApproved` — tagline and description approved
- [x] `imagesConfirmed` — real photos are in
- [x] `instagramConfirmed` — real Instagram is in
- [ ] `locationConfirmed` — real `LOCATION` (display name, `mapsUrl`, and address fields)
- [ ] `pricingConfirmed` — real prices in `PRICING`
- [ ] `testimonialsConfirmed` — real reviews in `TESTIMONIALS` (photo is optional; without one a small logo badge is shown)
- [ ] `policiesReady` — real wording added to `/privacy`, `/terms`, `/cancellation`, `/booking-policy` (edit `src/components/PolicyPage.jsx` or give each page its own content)
- [ ] `allowIndexing` — **last**, on launch day; lets Google index the site and publishes `robots.txt` / sitemap

### SEO behaviour

- Title: *Naksha Mehndi | Bridal & Wedding Mehendi Artist*. The description makes no city or location claim.
- Open Graph + Twitter cards, favicon, semantic HTML with one `<h1>`, descriptive alt text.
- `robots.txt` blocks all crawlers and the pages are `noindex` until `allowIndexing` is `true`. This stops demo content from being indexed by accident.
- **LocalBusiness structured data is not output** until `locationConfirmed` is `true` **and** `streetAddress` and `locality` are filled in. Opening-hours schema is intentionally left out because the opening *days* are not confirmed; add `openingHoursSpecification` in `src/lib/schema.js` once they are.
- Policy pages are `noindex` and left out of the sitemap until `policiesReady` is `true`.

---

## Deploying to Vercel

1. Push this folder to a GitHub repository (`git init`, commit, push).
2. In Vercel: **Add New → Project →** import the repository. The framework is detected as Next.js; keep the defaults (build command `next build`, no output directory).
3. **Environment variables:** none required. Optionally add `NEXT_PUBLIC_SITE_URL` (your final domain, e.g. `https://www.yourdomain.com`) so canonical URLs, Open Graph and the sitemap use your final domain.
4. Click **Deploy**. Every push to `main` redeploys automatically.

### Custom domain

1. Vercel project → **Settings → Domains → Add** your domain (e.g. `www.yourdomain.com`; add the bare domain too and let Vercel redirect it).
2. At your domain registrar, add the DNS records Vercel shows: normally an **A record** `76.76.21.21` for the bare domain and a **CNAME** `cname.vercel-dns.com` for `www` (use the exact values Vercel displays, as they can change).
3. Wait for DNS to propagate (minutes to a few hours); Vercel issues the HTTPS certificate automatically.
4. Set `NEXT_PUBLIC_SITE_URL` to the final URL and redeploy.
5. Flip `allowIndexing` to `true` (after the rest of the launch checklist), redeploy, then submit `https://yourdomain.com/sitemap.xml` in Google Search Console.

---

## Project structure

```
src/
  config/siteConfig.js     ← all client data + launch flags (edit this)
  config/logoMark.mjs      ← logo mark geometry
  lib/contact.js           ← WhatsApp / tel / mail links + enquiry message
  lib/schema.js            ← LocalBusiness JSON-LD (gated)
  components/              ← Navbar, Hero, About, Services, Portfolio, Pricing,
                             Testimonials, InstagramStrip, Contact, EnquiryForm,
                             Footer, StickyWhatsApp, Logo, Icons, …
  app/                     ← layout (SEO), page, robots, sitemap, policy pages, favicon
public/images/             ← the client's photos
public/logo/               ← logo SVG / PNG files
scripts/                   ← brand / favicon / link-preview generator
```

Notes: the logo wordmark inside the `public/logo/*.svg` files is live text in Cormorant Garamond (falls back to Georgia). On the website the wordmark uses the loaded web font. For print or merchandise, open the SVG in a design tool with the font installed and convert text to outlines.
