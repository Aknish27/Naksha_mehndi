// =============================================================================
// NAKSHA MEHNDI — CENTRAL SITE CONFIGURATION
// =============================================================================
// Everything that changes per client lives in THIS file.
//
//   1. CONFIRMED  — information the client has verified. Safe to publish.
//   2. DEMO       — placeholders. Marked "DEMO — REPLACE BEFORE PRODUCTION".
//   3. LAUNCH_CHECKLIST — flip each flag to `true` once you've replaced the
//      matching demo content. Flags control demo notices on the site, whether
//      search engines may index it, and whether LocalBusiness schema is output.
//
// Search this file for "DEMO — REPLACE BEFORE PRODUCTION" to find every
// placeholder.
// =============================================================================

// -----------------------------------------------------------------------------
// 1. CONFIRMED INFORMATION (client-verified)
// -----------------------------------------------------------------------------
export const CONFIRMED = {
  businessName: "Naksha Mehndi", // exact spelling — use everywhere
  // Updated 9 Oct 2026: new number supplied by the client (+91 87547 91309).
  // ASSUMPTION: the same number is used for calls AND WhatsApp. If WhatsApp is on a
  // different number, change only `whatsappDigits`.
  phoneDisplay: "87547 91309",
  phoneDigits: "8754791309",
  whatsappDigits: "8754791309",
  // ASSUMPTION: Indian number. wa.me links need the country code. Change if wrong.
  countryCode: "91",
  email: "aknishtech27@gmail.com",
  hours: "9:00 AM – 7:00 PM",
  experienceYears: 10,
  realPhotoCount: 10, // real client photos now in /public/images (gallery-1 … gallery-10)
};

// Hero stats row. Edit freely. The services count is derived from SERVICES below, so it
// stays accurate if services are added or removed.
// (This replaces the old "Styles: 3" tile, which understated the range of work.)
export const HERO_STATS = {
  experienceLabel: "Experience",
  servicesLabel: "Services",
  servicesNote: "Bridal · Arabic · Traditional · Minimal · Custom",
  serviceAreaLabel: "Service",
  serviceAreaValue: "Home & event",
};

// Confirmed: the business offers ALL of these services.
// The service NAMES are confirmed. The `desc` lines are DRAFT COPY written by
// the designer — review them with the client and edit freely.
export const SERVICES = [
  { id: "bridal", name: "Bridal Mehendi", featured: true, desc: "Detailed designs for the bride’s hands and feet, created for your wedding day." },
  { id: "engagement", name: "Engagement Mehendi", desc: "Graceful designs to celebrate your engagement." },
  { id: "baby-shower", name: "Baby Shower Mehendi", desc: "Soft, joyful designs for the mother-to-be and her guests." },
  { id: "party", name: "Party Mehendi", desc: "Beautiful designs for parties, festivals and get-togethers." },
  { id: "arabic", name: "Arabic Mehendi", desc: "Bold, flowing vines and florals with open, airy spacing." },
  { id: "traditional", name: "Traditional Mehendi", desc: "Classic Indian motifs — paisleys, mandalas and fine detail." },
  { id: "minimal", name: "Minimal Mehendi", desc: "Fine, understated designs for a delicate, modern look." },
  { id: "custom", name: "Custom Mehendi Designs", desc: "A design created around your idea, outfit or theme." },
  { id: "home", name: "Home Service", desc: "Mehendi in the comfort of your own home." },
  { id: "event", name: "Event Mehendi Services", desc: "Mehendi for weddings, celebrations and group events." },
];

// -----------------------------------------------------------------------------
// 2. DEMO / PLACEHOLDER CONTENT
// -----------------------------------------------------------------------------

// DEMO — REPLACE BEFORE PRODUCTION
// Tagline & description are designer-written drafts (the client has none yet).
// The description uses ONLY confirmed facts. Approve or edit, then set
// LAUNCH_CHECKLIST.copyApproved = true.
export const COPY = {
  tagline: "Stories told in henna.",
  // Alternatives considered: "Every line, a love letter." / "Drawn by hand. Kept in memory."
  description:
    "Naksha Mehndi is a Mehendi studio with 10 years of experience creating bridal, engagement, baby shower, party and custom henna designs — in Arabic, traditional and minimal styles. Home and event services available.",
  seoTitle: "Naksha Mehndi | Bridal & Wedding Mehendi Artist",
  // Truthful, with NO city or location claim.
  seoDescription:
    "Naksha Mehndi — bridal, engagement, baby shower, party and custom Mehendi designs in Arabic, traditional and minimal styles. 10 years of experience. Home and event service. Enquire on WhatsApp.",
};

// CONFIRMED (client supplied, 9 Oct 2026). The tracking parameter (?stkn=…) from the
// shared link was removed on purpose.
export const INSTAGRAM = {
  handle: "nakshu_mehandhi",
  url: "https://www.instagram.com/nakshu_mehandhi",
};

// Other social links. Leave a value empty ("") to hide it everywhere.
export const OTHER_SOCIALS = {
  facebook: "",
};

// DEMO — REPLACE BEFORE PRODUCTION
// Not a real address. The "Open in Google Maps" button stays hidden until
// LAUNCH_CHECKLIST.locationConfirmed is true.
export const LOCATION = {
  displayName: "Demo Location — Replace Before Launch",
  mapsUrl: "DEMO_MAP_URL",
  // Fill these in with the real address to enable LocalBusiness schema:
  streetAddress: "",
  locality: "",
  region: "",
  postalCode: "",
  country: "IN",
};

// DEMO — REPLACE BEFORE PRODUCTION
// TODO: Replace demo pricing with client's actual pricing
// "price" strings are shown exactly as written. null price + `label` shows the label instead.
export const PRICING = {
  prefix: "Starting from",
  note: "Final pricing depends on the design, coverage and location. Message us for a personal quote.",
  items: [
    { service: "Bridal Mehendi", price: "₹X,XXX", featured: true },
    { service: "Engagement Mehendi", price: "₹X,XXX" },
    { service: "Party Mehendi", price: "₹XXX" },
    { service: "Custom Mehendi", price: null, label: "Contact for pricing" },
  ],
};

// DEMO — REPLACE BEFORE PRODUCTION
// Demo testimonials contain NO realistic review text on purpose, so they can
// never be mistaken for genuine reviews. Replace photo, name, event and quote.
// `photo` is optional: leave it "" and a small logo badge is shown instead.
// To add a photo, put it in /public/images/ and set e.g. photo: "/images/testimonial-1.jpg".
export const TESTIMONIALS = [
  {
    quote: "Sample review text goes here. Replace this with the customer’s own words.",
    name: "Customer Name",
    event: "Event type",
    photo: "",
  },
  {
    quote: "Sample review text goes here. Replace this with the customer’s own words.",
    name: "Customer Name",
    event: "Event type",
    photo: "",
  },
  {
    quote: "Sample review text goes here. Replace this with the customer’s own words.",
    name: "Customer Name",
    event: "Event type",
    photo: "",
  },
];

// -----------------------------------------------------------------------------
// IMAGES — the client's REAL work photos (added 9 Oct 2026).
// To swap a photo: replace the file in /public/images/ (same name). If its shape
// changes, update width/height here so the gallery doesn't jump while loading.
// Categories below are the designer's best guess from the photos — edit freely.
// -----------------------------------------------------------------------------
export const IMAGES = {
  hero: { src: "/images/hero.jpg", width: 1024, height: 1280, alt: "Bridal Mehendi on both hands with a large mandala on each palm" },
  about: { src: "/images/about.jpg", width: 959, height: 1280, alt: "Full-arm Mehendi with elephants, lotus bands and a palm mandala" },
  about2: { src: "/images/about-2.jpg", width: 960, height: 1280, alt: "Mehendi with a little Krishna figure on each palm" },
  bridal1: { src: "/images/bridal-1.jpg", width: 960, height: 1280, alt: "Bridal Mehendi with peacocks, lotus and fine lattice work" },
  bridal2: { src: "/images/bridal-2.jpg", width: 960, height: 1280, alt: "Mehendi with a palace, peacock and Ganesha motif" },
  og: { src: "/images/og-image.jpg", width: 1200, height: 630, alt: "Naksha Mehndi — Bridal & Wedding Mehendi Artist" },
};

// Portfolio filter tabs. A category with no photos is hidden automatically.
export const PORTFOLIO_CATEGORIES = ["Bridal", "Engagement", "Arabic", "Traditional", "Minimal", "Party", "Custom", "Baby Shower"];

export const GALLERY = [
  { src: "/images/gallery-1.jpg", width: 960, height: 1280, category: "Bridal", alt: "Bridal Mehendi with peacocks, lotus and fine lattice work" },
  { src: "/images/gallery-10.jpg", width: 1024, height: 1280, category: "Traditional", alt: "Traditional full-arm Mehendi with mandala palms" },
  { src: "/images/gallery-6.jpg", width: 960, height: 1280, category: "Baby Shower", alt: "Baby shower Mehendi with Mom to Be, Dad to Be and a pram design" },
  { src: "/images/gallery-3.jpg", width: 960, height: 1280, category: "Custom", alt: "Custom Mehendi with a palace, peacock, lotus and Ganesha motifs" },
  { src: "/images/gallery-7.jpg", width: 1024, height: 1279, category: "Bridal", alt: "Bridal Mehendi on hands and feet with a Finally Forever message" },
  { src: "/images/gallery-4.jpg", width: 960, height: 1280, category: "Arabic", alt: "Arabic-style Mehendi with flowing paisley and floral lines" },
  { src: "/images/gallery-2.jpg", width: 959, height: 1280, category: "Traditional", alt: "Traditional Mehendi with elephant bands and a palm mandala" },
  { src: "/images/gallery-8.jpg", width: 960, height: 1280, category: "Bridal", alt: "Bridal Mehendi with peacocks and a personalised message on the palms" },
  { src: "/images/gallery-5.jpg", width: 960, height: 1280, category: "Custom", alt: "Custom Mehendi with a little Krishna on each palm and elephants under an umbrella" },
  { src: "/images/gallery-9.jpg", width: 1024, height: 1280, category: "Bridal", alt: "Bridal Mehendi with peacocks, roses and personalised names on the palms" },
];

// Square crops used in the Instagram strip.
export const INSTAGRAM_IMAGES = [
  { src: "/images/instagram-1.jpg", alt: "Baby shower Mehendi design" },
  { src: "/images/instagram-2.jpg", alt: "Mehendi with Krishna figures on the palms" },
  { src: "/images/instagram-3.jpg", alt: "Custom Mehendi with palace and lotus motifs" },
  { src: "/images/instagram-4.jpg", alt: "Arabic-style Mehendi design" },
  { src: "/images/instagram-5.jpg", alt: "Bridal Mehendi with palm mandalas" },
  { src: "/images/instagram-6.jpg", alt: "Mehendi with peacocks and personalised names" },
];

// -----------------------------------------------------------------------------
// ENQUIRY FORM OPTIONS
// -----------------------------------------------------------------------------
export const ENQUIRY = {
  eventTypes: ["Wedding (Bride)", "Wedding (Guest / Bridesmaid)", "Engagement", "Baby Shower", "Party", "Other event"],
  // Services dropdown is built from SERVICES, plus this extra option:
  extraServiceOption: "Not sure yet",
};

// -----------------------------------------------------------------------------
// 3. LAUNCH CHECKLIST — flip to `true` as each item is replaced with real data
// -----------------------------------------------------------------------------
export const LAUNCH_CHECKLIST = {
  copyApproved: false, // tagline + description approved by client
  imagesConfirmed: true, // real client photos are in /public/images (testimonial avatars are still demo)
  instagramConfirmed: true, // real account supplied by the client
  locationConfirmed: false, // LOCATION replaced with the real address / Maps link
  pricingConfirmed: false, // PRICING replaced with the real prices
  testimonialsConfirmed: false, // TESTIMONIALS replaced with real reviews
  policiesReady: false, // /privacy, /terms, /cancellation, /booking-policy have real content

  // Search engines are told NOT to index the site until this is true.
  // Set to true on launch day, after everything above is done.
  allowIndexing: false,
};

// -----------------------------------------------------------------------------
// DERIVED VALUES — you should not need to edit anything below this line
// -----------------------------------------------------------------------------
const whatsappNumber = `${CONFIRMED.countryCode}${CONFIRMED.whatsappDigits}`;

export const siteConfig = {
  name: CONFIRMED.businessName,
  tagline: COPY.tagline,
  description: COPY.description,
  seoTitle: COPY.seoTitle,
  seoDescription: COPY.seoDescription,
  siteUrl:
    process.env.NEXT_PUBLIC_SITE_URL ||
    (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : "http://localhost:3000"),
  contact: {
    phoneDisplay: CONFIRMED.phoneDisplay,
    phoneTel: `+${CONFIRMED.countryCode}${CONFIRMED.phoneDigits}`,
    whatsappNumber,
    email: CONFIRMED.email,
    hours: CONFIRMED.hours,
  },
  experienceYears: CONFIRMED.experienceYears,
  heroStats: HERO_STATS,
  services: SERVICES,
  instagram: INSTAGRAM,
  socials: OTHER_SOCIALS,
  location: LOCATION,
  pricing: PRICING,
  testimonials: TESTIMONIALS,
  images: IMAGES,
  gallery: GALLERY,
  portfolioCategories: PORTFOLIO_CATEGORIES,
  instagramImages: INSTAGRAM_IMAGES,
  enquiry: ENQUIRY,
  checklist: LAUNCH_CHECKLIST,
};

export default siteConfig;
