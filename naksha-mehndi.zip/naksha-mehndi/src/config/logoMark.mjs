// Naksha Mehndi — logo mark, shared by the React <Logo/> component and by
// scripts/generate-brand.mjs (which writes the static SVG/PNG files).
//
// Concept: a jharokha / mehrab ARCH (Indian palace window, the bridal frame)
// holding a symmetrical LOTUS. Fine line-work reads as henna being drawn by hand.
//
// viewBox: 0 0 100 100.  `stroke` = main line colour, `accent` = gold detail.

export const MARK_VIEWBOX = "0 0 100 100";

export function markInner(stroke, accent) {
  return `
<g fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path d="M20 90V52C20 34 36 26 50 6C64 26 80 34 80 52V90" stroke="${stroke}" stroke-width="1.7"/>
  <path d="M26 90V54C26 39 39 32 50 15C61 32 74 39 74 54V90" stroke="${accent}" stroke-width="0.9"/>
  <path d="M13 90H87" stroke="${stroke}" stroke-width="1.7"/>
  <path d="M50 82C41 71 41 58 50 47C59 58 59 71 50 82Z" stroke="${stroke}" stroke-width="1.5" fill="${accent}" fill-opacity="0.28"/>
  <path d="M50 82C38 79 32 69 34 58C43 61 48 70 50 82Z" stroke="${stroke}" stroke-width="1.4"/>
  <path d="M50 82C62 79 68 69 66 58C57 61 52 70 50 82Z" stroke="${stroke}" stroke-width="1.4"/>
  <path d="M50 47C50 41 50 37 50 33" stroke="${accent}" stroke-width="1.1"/>
  <circle cx="50" cy="28" r="1.9" fill="${accent}" stroke="none"/>
  <circle cx="42" cy="41" r="1.1" fill="${accent}" stroke="none"/>
  <circle cx="58" cy="41" r="1.1" fill="${accent}" stroke="none"/>
  <circle cx="31" cy="90" r="1.2" fill="${accent}" stroke="none"/>
  <circle cx="69" cy="90" r="1.2" fill="${accent}" stroke="none"/>
</g>`;
}

export const BRAND = {
  green: "#5E1533", // deep wine (kept the old key name so the generators still work)
  ivory: "#FFF8EE",
  gold: "#B84E0A", // saffron, for light backgrounds
  goldLight: "#F4B83F", // marigold, for dark backgrounds
  ink: "#2E1119",
};
