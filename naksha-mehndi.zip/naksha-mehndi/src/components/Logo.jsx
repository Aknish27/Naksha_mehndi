import { markInner, MARK_VIEWBOX, BRAND } from "@/config/logoMark.mjs";

const TONES = {
  // "light" = for light backgrounds, "dark" = for dark backgrounds
  light: { stroke: BRAND.green, accent: BRAND.gold, text: "text-ink", sub: "text-gold" },
  dark: { stroke: BRAND.goldLight, accent: BRAND.goldLight, text: "text-ivory", sub: "text-gold-light" },
};

export function LogoMark({ size = 40, tone = "light", className = "" }) {
  const c = TONES[tone];
  return (
    <svg
      viewBox={MARK_VIEWBOX}
      width={size}
      height={size}
      className={className}
      aria-hidden="true"
      focusable="false"
      dangerouslySetInnerHTML={{ __html: markInner(c.stroke, c.accent) }}
    />
  );
}

/**
 * Naksha Mehndi logo: arch + lotus mark with a serif wordmark.
 * variant: "horizontal" (default) | "stacked" | "compact" (mark + "Naksha" only)
 */
export default function Logo({ variant = "horizontal", tone = "light", className = "" }) {
  const c = TONES[tone];

  if (variant === "stacked") {
    return (
      <span className={`inline-flex flex-col items-center text-center ${className}`} aria-label="Naksha Mehndi">
        <LogoMark size={64} tone={tone} />
        <span className={`mt-3 font-serif text-3xl font-medium leading-none ${c.text}`}>Naksha</span>
        <span className={`mt-1.5 text-[10px] font-medium uppercase tracking-[0.5em] ${c.sub}`}>Mehndi</span>
      </span>
    );
  }

  if (variant === "compact") {
    return (
      <span className={`inline-flex items-center gap-2 ${className}`} aria-label="Naksha Mehndi">
        <LogoMark size={34} tone={tone} />
        <span className={`font-serif text-2xl font-medium leading-none ${c.text}`}>Naksha</span>
      </span>
    );
  }

  return (
    <span className={`inline-flex items-center gap-3 ${className}`} aria-label="Naksha Mehndi">
      <LogoMark size={44} tone={tone} />
      <span className="flex flex-col leading-none">
        <span className={`font-serif text-[1.7rem] font-medium ${c.text}`}>Naksha</span>
        <span className={`mt-1 text-[9px] font-medium uppercase tracking-[0.5em] ${c.sub}`}>Mehndi</span>
      </span>
    </span>
  );
}
