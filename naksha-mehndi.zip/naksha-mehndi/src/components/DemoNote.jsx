/**
 * Small "Demo" tag shown next to placeholder content.
 * Pass `show={!siteConfig.checklist.xConfirmed}` so it disappears automatically
 * once the matching LAUNCH_CHECKLIST flag is set to true.
 */
export default function DemoNote({ show, children = "Demo", className = "" }) {
  if (!show) return null;
  return <span className={`demo-tag ${className}`}>{children}</span>;
}
