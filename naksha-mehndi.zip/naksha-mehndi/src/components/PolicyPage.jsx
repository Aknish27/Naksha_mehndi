import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { VineDivider } from "@/components/Ornament";

/**
 * Placeholder policy page. NO legal wording is invented here.
 * To add real content, replace the <p> below with the client's approved text
 * and set LAUNCH_CHECKLIST.policiesReady = true in siteConfig.js.
 */
export default function PolicyPage({ title }) {
  return (
    <>
      <Navbar />
      <main className="section-pad min-h-[70vh] bg-ivory pt-40">
        <div className="container-x max-w-2xl">
          <p className="eyebrow">Naksha Mehndi</p>
          <h1 className="mt-4 text-5xl text-ink md:text-6xl">{title}</h1>
          <VineDivider className="mt-8 text-gold" />
          <p className="mt-10 border border-dashed border-gold/70 p-6 font-serif text-2xl italic text-ink-soft">
            Policy content to be added before production launch.
          </p>
          <a href="/" className="btn btn-outline mt-10">
            ← Back to home
          </a>
        </div>
      </main>
      <Footer />
    </>
  );
}
