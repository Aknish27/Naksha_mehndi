import PolicyPage from "@/components/PolicyPage";

// Placeholder until the client supplies real policy wording (see PolicyPage.jsx).
export const metadata = {
  title: "Booking Policy",
  robots: { index: false, follow: false },
};

export default function Page() {
  return <PolicyPage title="Booking Policy" />;
}
