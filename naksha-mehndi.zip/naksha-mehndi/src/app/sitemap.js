import siteConfig from "@/config/siteConfig";

export default function sitemap() {
  const { siteUrl, checklist } = siteConfig;
  const now = new Date();

  const pages = [{ url: siteUrl, lastModified: now, changeFrequency: "monthly", priority: 1 }];

  // Policy pages are placeholders until real wording is added, so keep them out of the sitemap.
  if (checklist.policiesReady) {
    for (const p of ["privacy", "terms", "cancellation", "booking-policy"]) {
      pages.push({ url: `${siteUrl}/${p}`, lastModified: now, changeFrequency: "yearly", priority: 0.3 });
    }
  }
  return pages;
}
