import siteConfig from "@/config/siteConfig";

export default function robots() {
  const { siteUrl, checklist } = siteConfig;

  // Until LAUNCH_CHECKLIST.allowIndexing is true, tell every crawler to stay out.
  if (!checklist.allowIndexing) {
    return { rules: [{ userAgent: "*", disallow: "/" }] };
  }
  return {
    rules: [{ userAgent: "*", allow: "/" }],
    sitemap: `${siteUrl}/sitemap.xml`,
  };
}
